#!/bin/bash
userhome=$HOME
if  [ -e /opt/PROG24 ]; then
/opt/PROG24
rm /opt/PROG24/Prog24cXX.desktop
rm /opt/PROG24/24Cxx_icon64.png
rm /opt/PROG24/24Cxx_icon48.png
rm /opt/PROG24/24Cxx_icon32.png
rm /opt/PROG24/prog24
rm /opt/PROG24/99-CH341.rules
rmdir /opt/PROG24
fi
cd /
if [ -e $userhome/"Рабочий стол" ]; then 
rm $userhome/"Рабочий стол"/Prog24cXX.desktop
fi
if [ -e $HOME/Desktop ]; then 
rm $userhome/Desktop/Prog24cXX.desktop
fi
rm /usr/share/applications/Prog24cXX.desktop
rm /usr/share/pixmaps/24Cxx_icon64.png
rm /usr/share/pixmaps/24Cxx_icon48.png
rm /usr/share/pixmaps/24Cxx_icon32.png
rm /etc/udev/rules.d/99-CH341.rules
